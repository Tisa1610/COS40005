import React, { useEffect, useState } from "react";
import axios from "axios";

function App() {
  const [metrics, setMetrics] = useState({});
  const [alerts, setAlerts] = useState([]);

  useEffect(() => {
    const fetchData = () => {
      axios.get("http://127.0.0.1:8000/metrics").then(res => setMetrics(res.data));
      axios.get("http://127.0.0.1:8000/alerts").then(res => setAlerts(res.data));
    };

    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <h1 className="text-3xl font-bold mb-6">System Monitor Dashboard</h1>
      <div className="grid grid-cols-2 gap-4 mb-6">
        <MetricCard label="CPU Usage" value={metrics.cpu_usage + "%"} />
        <MetricCard label="RAM Usage" value={metrics.ram_usage + "%"} />
        <MetricCard label="Temperature" value={metrics.temperature + " °C"} />
        <MetricCard label="Packet Count" value={metrics.packet_count} />
      </div>
      <h2 className="text-2xl font-semibold mb-2">Alerts</h2>
      <div className="bg-white rounded-xl shadow-md p-4">
        {alerts.length === 0 ? (
          <p>No alerts yet.</p>
        ) : (
          <ul className="divide-y divide-gray-200">
            {alerts.map((alert, index) => (
              <li key={index} className="py-2 text-sm">
                <span className={`font-bold ${alert.level === "ERROR" ? "text-red-500" : "text-yellow-600"}`}>
                  [{alert.level}]
                </span>{" "}
                {alert.timestamp}: {alert.message}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

const MetricCard = ({ label, value }) => (
  <div className="bg-white p-4 rounded-xl shadow-md">
    <p className="text-sm text-gray-500">{label}</p>
    <p className="text-xl font-semibold">{value}</p>
  </div>
);

export default App;
